-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: 127.0.0.1	Database: saas_payments
-- ------------------------------------------------------
-- Server version 	10.4.32-MariaDB
-- Date: Sat, 15 Nov 2025 03:52:55 +0100

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned DEFAULT NULL COMMENT 'ID do tenant (null para master key)',
  `user_id` int(11) DEFAULT NULL COMMENT 'ID do usuário (quando aplicável)',
  `endpoint` varchar(255) NOT NULL COMMENT 'Endpoint/URL acessada',
  `method` varchar(10) NOT NULL COMMENT 'Método HTTP (GET, POST, PUT, DELETE, etc)',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'Endereço IP do cliente (suporta IPv4 e IPv6)',
  `user_agent` text DEFAULT NULL COMMENT 'User-Agent do cliente',
  `request_body` text DEFAULT NULL COMMENT 'Corpo da requisição (JSON, limitado a 10KB)',
  `response_status` int(3) NOT NULL COMMENT 'Status HTTP da resposta',
  `response_time` int(11) NOT NULL COMMENT 'Tempo de resposta em milissegundos',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Data e hora da requisição',
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_method` (`method`),
  KEY `idx_response_status` (`response_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_tenant_created` (`tenant_id`,`created_at`),
  CONSTRAINT `fk_audit_logs_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de logs de auditoria - rastreabilidade de ações';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `audit_logs` VALUES (1,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,150,'2025-11-14 22:53:29'),(2,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:53:35'),(3,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,1,'2025-11-14 22:54:00'),(4,1,NULL,'/v1/stats','GET','::1',NULL,NULL,200,2,'2025-11-14 22:54:07'),(5,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,1,'2025-11-14 22:54:14'),(6,1,NULL,'/v1/customers','POST','::1',NULL,'{\"email\":\"teste@example.com\",\"name\":\"Teste\"}',200,3031,'2025-11-14 22:54:23'),(7,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,5,'2025-11-14 22:56:16'),(8,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,3,'2025-11-14 22:56:22'),(9,1,NULL,'/v1/audit-logs/6','GET','::1',NULL,NULL,200,2,'2025-11-14 22:56:29'),(10,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,44,'2025-11-14 22:57:01'),(11,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,3,'2025-11-14 22:57:08'),(12,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:57:14'),(13,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:57:21'),(14,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:57:27'),(15,1,NULL,'/v1/audit-logs/99999','GET','::1',NULL,NULL,200,1,'2025-11-14 22:57:34'),(16,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:57:40'),(17,1,NULL,'/v1/audit-logs','GET','::1',NULL,NULL,200,2,'2025-11-14 22:57:47'),(18,1,NULL,'/v1/audit-logs/99999','GET','::1',NULL,NULL,200,1,'2025-11-14 22:58:36'),(19,1,NULL,'/v1/audit-logs/99999','GET','::1',NULL,NULL,200,1,'2025-11-14 22:58:57'),(20,1,NULL,'/v1/subscriptions','POST','::1',NULL,'{\"customer_id\":1,\"price_id\":\"price_1STWCtByYvrEJg7O0Q5siyvS\"}',200,2147,'2025-11-14 23:15:19'),(21,1,NULL,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,3,'2025-11-14 23:16:36'),(22,1,NULL,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,3,'2025-11-14 23:16:43'),(23,1,NULL,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,3,'2025-11-14 23:17:14'),(24,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,147,'2025-11-15 00:19:11'),(25,1,2,'/v1/auth/me','GET','::1',NULL,NULL,200,2,'2025-11-15 00:19:17'),(26,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,66,'2025-11-15 00:19:24'),(27,1,2,'/v1/customers','GET','::1',NULL,NULL,200,13,'2025-11-15 00:19:31'),(28,1,2,'/v1/auth/logout','POST','::1',NULL,'[]',200,312,'2025-11-15 00:19:37'),(29,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,1,'2025-11-15 00:19:44'),(30,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,116,'2025-11-15 00:20:20'),(31,1,2,'/v1/auth/me','GET','::1',NULL,NULL,200,1,'2025-11-15 00:20:26'),(32,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,67,'2025-11-15 00:20:33'),(33,1,2,'/v1/customers','GET','::1',NULL,NULL,200,1,'2025-11-15 00:20:39'),(34,1,2,'/v1/auth/logout','POST','::1',NULL,'[]',200,69,'2025-11-15 00:20:46'),(35,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,1,'2025-11-15 00:20:52'),(36,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,136,'2025-11-15 00:22:12'),(37,1,2,'/v1/auth/me','GET','::1',NULL,NULL,200,1,'2025-11-15 00:22:19'),(38,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',401,70,'2025-11-15 00:22:25'),(39,1,2,'/v1/customers','GET','::1',NULL,NULL,200,1,'2025-11-15 00:22:32'),(40,1,2,'/v1/auth/logout','POST','::1',NULL,'[]',200,83,'2025-11-15 00:22:38'),(41,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,30,'2025-11-15 00:22:45'),(42,1,NULL,'/v1/subscriptions','GET','::1',NULL,NULL,200,17,'2025-11-15 00:49:30'),(43,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,9,'2025-11-15 00:49:36'),(44,1,NULL,'/v1/customers','POST','::1',NULL,'{\"email\":\"test_1763167776@example.com\",\"name\":\"Test Customer\"}',200,2100,'2025-11-15 00:49:45'),(45,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,208,'2025-11-15 00:49:52'),(46,1,2,'/v1/subscriptions','GET','::1',NULL,NULL,200,2,'2025-11-15 00:49:58'),(47,1,2,'/v1/customers','GET','::1',NULL,NULL,200,2,'2025-11-15 00:50:05'),(48,1,2,'/v1/audit-logs','GET','::1',NULL,NULL,200,5,'2025-11-15 00:50:11'),(49,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,147,'2025-11-15 00:50:18'),(50,1,3,'/v1/subscriptions','GET','::1',NULL,NULL,200,12,'2025-11-15 00:50:24'),(51,1,3,'/v1/customers','GET','::1',NULL,NULL,200,2,'2025-11-15 00:50:31'),(52,1,3,'/v1/customers','POST','::1',NULL,'{\"email\":\"editor_test_1763167831@example.com\",\"name\":\"Editor Test Customer\"}',200,856,'2025-11-15 00:50:38'),(53,1,3,'/v1/audit-logs','GET','::1',NULL,NULL,403,3,'2025-11-15 00:50:45'),(54,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"viewer@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,147,'2025-11-15 00:50:51'),(55,1,4,'/v1/subscriptions','GET','::1',NULL,NULL,200,3,'2025-11-15 00:50:58'),(56,1,4,'/v1/customers','GET','::1',NULL,NULL,200,3,'2025-11-15 00:51:04'),(57,1,4,'/v1/customers','POST','::1',NULL,'{\"email\":\"viewer_test_1763167864@example.com\",\"name\":\"Viewer Test Customer\"}',403,2,'2025-11-15 00:51:10'),(58,1,4,'/v1/audit-logs','GET','::1',NULL,NULL,403,2,'2025-11-15 00:51:17'),(59,1,NULL,'/v1/subscriptions','GET','::1',NULL,NULL,200,2,'2025-11-15 00:51:23'),(60,1,3,'/v1/subscriptions/1','DELETE','::1',NULL,NULL,403,3,'2025-11-15 00:51:29'),(61,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,28,'2025-11-15 00:51:36'),(62,1,4,'/v1/customers/1','PUT','::1',NULL,'{\"name\":\"Updated Name\"}',403,72,'2025-11-15 00:51:42'),(63,1,NULL,'/v1/subscriptions','GET','::1',NULL,NULL,200,2,'2025-11-15 00:52:15'),(64,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,2,'2025-11-15 00:52:21'),(65,1,NULL,'/v1/customers','POST','::1',NULL,'{\"email\":\"test_1763167941@example.com\",\"name\":\"Test Customer\"}',200,903,'2025-11-15 00:52:28'),(66,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,136,'2025-11-15 00:52:35'),(67,1,2,'/v1/subscriptions','GET','::1',NULL,NULL,200,4,'2025-11-15 00:52:41'),(68,1,2,'/v1/customers','GET','::1',NULL,NULL,200,3,'2025-11-15 00:52:48'),(69,1,2,'/v1/audit-logs','GET','::1',NULL,NULL,200,16,'2025-11-15 00:52:54'),(70,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,203,'2025-11-15 00:53:01'),(71,1,3,'/v1/subscriptions','GET','::1',NULL,NULL,200,4,'2025-11-15 00:53:07'),(72,1,3,'/v1/customers','GET','::1',NULL,NULL,200,2,'2025-11-15 00:53:14'),(73,1,3,'/v1/customers','POST','::1',NULL,'{\"email\":\"editor_test_1763167994@example.com\",\"name\":\"Editor Test Customer\"}',200,858,'2025-11-15 00:53:21'),(74,1,3,'/v1/audit-logs','GET','::1',NULL,NULL,403,3,'2025-11-15 00:53:27'),(75,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"viewer@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,147,'2025-11-15 00:53:34'),(76,1,4,'/v1/subscriptions','GET','::1',NULL,NULL,200,8,'2025-11-15 00:53:40'),(77,1,4,'/v1/customers','GET','::1',NULL,NULL,200,3,'2025-11-15 00:53:47'),(78,1,4,'/v1/customers','POST','::1',NULL,'{\"email\":\"viewer_test_1763168027@example.com\",\"name\":\"Viewer Test Customer\"}',403,2,'2025-11-15 00:53:53'),(79,1,4,'/v1/audit-logs','GET','::1',NULL,NULL,403,3,'2025-11-15 00:54:00'),(80,1,NULL,'/v1/subscriptions','GET','::1',NULL,NULL,200,2,'2025-11-15 00:54:06'),(81,1,3,'/v1/subscriptions/1','DELETE','::1',NULL,NULL,403,3,'2025-11-15 00:54:12'),(82,1,NULL,'/v1/customers','GET','::1',NULL,NULL,200,2,'2025-11-15 00:54:19'),(83,1,4,'/v1/customers/1','PUT','::1',NULL,'{\"name\":\"Updated Name\"}',403,2,'2025-11-15 00:54:25'),(84,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,169,'2025-11-15 01:05:16'),(85,1,2,'/v1/users','GET','::1',NULL,NULL,200,26,'2025-11-15 01:05:23'),(86,1,2,'/v1/users','POST','::1',NULL,'{\"email\":\"test_user_1763168723@example.com\",\"password\":\"[REDACTED]\",\"name\":\"Test User\",\"role\":\"viewer\"}',200,319,'2025-11-15 01:05:30'),(87,1,2,'/v1/users/5','GET','::1',NULL,NULL,200,3,'2025-11-15 01:05:36'),(88,1,2,'/v1/users/5','PUT','::1',NULL,'{\"name\":\"Updated Test User\",\"status\":\"active\"}',200,70,'2025-11-15 01:05:43'),(89,1,2,'/v1/users/5/role','PUT','::1',NULL,'{\"role\":\"editor\"}',200,70,'2025-11-15 01:05:49'),(90,1,2,'/v1/users/5','DELETE','::1',NULL,NULL,200,58,'2025-11-15 01:05:56'),(91,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,179,'2025-11-15 01:06:02'),(92,1,3,'/v1/users','GET','::1',NULL,NULL,403,3,'2025-11-15 01:06:09'),(93,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"viewer@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,174,'2025-11-15 01:06:15'),(94,1,4,'/v1/users','GET','::1',NULL,NULL,403,26,'2025-11-15 01:06:22'),(95,1,NULL,'/v1/users','GET','::1',NULL,NULL,200,2,'2025-11-15 01:06:28'),(96,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,147,'2025-11-15 01:09:35'),(97,1,2,'/v1/users','GET','::1',NULL,NULL,200,3,'2025-11-15 01:09:41'),(98,1,2,'/v1/users','POST','::1',NULL,'{\"email\":\"test_user_1763168981@example.com\",\"password\":\"[REDACTED]\",\"name\":\"Test User\",\"role\":\"viewer\"}',200,263,'2025-11-15 01:09:48'),(99,1,2,'/v1/users/6','GET','::1',NULL,NULL,200,95,'2025-11-15 01:09:55'),(100,1,2,'/v1/users/6','PUT','::1',NULL,'{\"name\":\"Updated Test User\",\"status\":\"active\"}',200,82,'2025-11-15 01:10:01'),(101,1,2,'/v1/users/6/role','PUT','::1',NULL,'{\"role\":\"editor\"}',200,188,'2025-11-15 01:10:08'),(102,1,2,'/v1/users/6','DELETE','::1',NULL,NULL,200,72,'2025-11-15 01:10:15'),(103,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,169,'2025-11-15 01:10:21'),(104,1,3,'/v1/users','GET','::1',NULL,NULL,403,7,'2025-11-15 01:10:28'),(105,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"viewer@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,113,'2025-11-15 01:10:35'),(106,1,4,'/v1/users','GET','::1',NULL,NULL,403,3,'2025-11-15 01:10:41'),(107,1,NULL,'/v1/users','GET','::1',NULL,NULL,403,0,'2025-11-15 01:10:48'),(108,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,114,'2025-11-15 01:19:53'),(109,1,2,'/v1/permissions','GET','::1',NULL,NULL,200,63,'2025-11-15 01:20:00'),(110,1,2,'/v1/users/4/permissions','GET','::1',NULL,NULL,200,13,'2025-11-15 01:20:06'),(111,1,2,'/v1/users/4/permissions','POST','::1',NULL,'{\"permission\":\"view_audit_logs\"}',200,58,'2025-11-15 01:20:13'),(112,1,2,'/v1/users/4/permissions','GET','::1',NULL,NULL,200,2,'2025-11-15 01:20:19'),(113,1,2,'/v1/users/4/permissions/view_audit_logs','DELETE','::1',NULL,NULL,200,47,'2025-11-15 01:20:26'),(114,1,2,'/v1/users/4/permissions','GET','::1',NULL,NULL,200,4,'2025-11-15 01:20:32'),(115,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,216,'2025-11-15 01:20:39'),(116,1,3,'/v1/permissions','GET','::1',NULL,NULL,403,39,'2025-11-15 01:20:46'),(117,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"viewer@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,191,'2025-11-15 01:20:52'),(118,1,4,'/v1/permissions','GET','::1',NULL,NULL,403,4,'2025-11-15 01:20:59'),(119,1,NULL,'/v1/permissions','GET','::1',NULL,NULL,403,1,'2025-11-15 01:21:05'),(120,1,2,'/v1/users/4/permissions','POST','::1',NULL,'{\"permission\":\"invalid_permission_xyz\"}',400,2,'2025-11-15 01:21:12'),(121,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,169,'2025-11-15 01:45:18'),(122,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,43,'2025-11-15 01:45:24'),(123,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,5,'2025-11-15 01:45:30'),(124,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,6,'2025-11-15 01:45:37'),(125,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,17,'2025-11-15 01:45:43'),(126,1,2,'/v1/subscriptions/1/history/stats','GET','::1',NULL,NULL,500,24,'2025-11-15 01:45:50'),(127,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,5,'2025-11-15 01:45:56'),(128,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,4,'2025-11-15 01:46:03'),(129,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,202,'2025-11-15 01:47:52'),(130,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,6,'2025-11-15 01:47:59'),(131,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,5,'2025-11-15 01:48:05'),(132,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,5,'2025-11-15 01:48:11'),(133,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,5,'2025-11-15 01:48:18'),(134,1,2,'/v1/subscriptions/1/history/stats','GET','::1',NULL,NULL,200,31,'2025-11-15 01:48:25'),(135,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,4,'2025-11-15 01:48:31'),(136,1,2,'/v1/subscriptions/1/history','GET','::1',NULL,NULL,200,3,'2025-11-15 01:48:38'),(137,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"admin@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,176,'2025-11-15 01:57:38'),(138,1,NULL,'/v1/disputes','GET','::1',NULL,NULL,200,1385,'2025-11-15 01:57:46'),(139,1,2,'/v1/disputes','GET','::1',NULL,NULL,200,1232,'2025-11-15 01:57:54'),(140,1,2,'/v1/disputes','GET','::1',NULL,NULL,200,874,'2025-11-15 01:58:01'),(141,1,2,'/v1/disputes','GET','::1',NULL,NULL,200,835,'2025-11-15 01:58:09'),(142,NULL,NULL,'/v1/auth/login','POST','::1',NULL,'{\"email\":\"editor@example.com\",\"password\":\"[REDACTED]\",\"tenant_id\":1}',200,126,'2025-11-15 01:58:16'),(143,1,3,'/v1/disputes','GET','::1',NULL,NULL,200,970,'2025-11-15 01:58:23'),(144,NULL,NULL,'/health/detailed','GET','::1',NULL,NULL,200,4435,'2025-11-15 02:15:01'),(145,NULL,NULL,'/health/detailed','GET','::1',NULL,NULL,200,4202,'2025-11-15 02:15:06');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `audit_logs` with 145 row(s)
--

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL COMMENT 'Nome do arquivo de backup',
  `file_path` text DEFAULT NULL COMMENT 'Caminho completo do arquivo de backup',
  `file_size` bigint(20) NOT NULL DEFAULT 0 COMMENT 'Tamanho do arquivo em bytes',
  `status` enum('success','failed') NOT NULL DEFAULT 'success' COMMENT 'Status do backup',
  `duration_seconds` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Duração do backup em segundos',
  `compressed` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Se o backup foi comprimido (gzip)',
  `error_message` text DEFAULT NULL COMMENT 'Mensagem de erro (se houver)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Data de criação do backup',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Logs de backups do banco de dados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `backup_logs` VALUES (1,'backup_saas_payments_2025-11-15_03-45-30.sql.gz','D:\\xampp\\htdocs\\saas-stripe\\backups\\backup_saas_payments_2025-11-15_03-45-30.sql.gz',9830,'success',1.96,1,NULL,'2025-11-15 06:45:32'),(2,'backup_saas_payments_2025-11-15_03-48-15.sql','D:\\xampp\\htdocs\\saas-stripe\\backups\\backup_saas_payments_2025-11-15_03-48-15.sql',0,'failed',0.19,1,'Arquivo de backup não foi criado: D:\\xampp\\htdocs\\saas-stripe\\backups\\backup_saas_payments_2025-11-15_03-48-15.sql.gz','2025-11-15 06:48:15'),(3,'backup_saas_payments_2025-11-15_03-49-18.sql.gz','D:\\xampp\\htdocs\\saas-stripe\\backups\\backup_saas_payments_2025-11-15_03-49-18.sql.gz',9957,'success',0.06,1,NULL,'2025-11-15 06:49:18');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `backup_logs` with 3 row(s)
--

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `stripe_customer_id` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_stripe_customer` (`stripe_customer_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_email` (`email`),
  CONSTRAINT `fk_customers_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de clientes Stripe';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `customers` VALUES (1,1,'cus_TQMcRQySh3zPfX','teste@example.com','Teste','[]','2025-11-14 22:54:23','2025-11-14 22:54:23'),(2,1,'cus_TQOT5dH7VoJcgk','test_1763167776@example.com','Test Customer','[]','2025-11-15 00:49:45','2025-11-15 00:49:45'),(3,1,'cus_TQOUSR3ffkFdZY','editor_test_1763167831@example.com','Editor Test Customer','[]','2025-11-15 00:50:38','2025-11-15 00:50:38'),(4,1,'cus_TQOWOYZyGMXHAN','test_1763167941@example.com','Test Customer','[]','2025-11-15 00:52:28','2025-11-15 00:52:28'),(5,1,'cus_TQOW4izMt9iJYM','editor_test_1763167994@example.com','Editor Test Customer','[]','2025-11-15 00:53:21','2025-11-15 00:53:21');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `customers` with 5 row(s)
--

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog`
--

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `phinxlog` VALUES (20250115000001,'InitialSchema','2025-11-14 23:54:45','2025-11-14 23:54:51',0),(20250116000001,'CreateBackupLogsTable','2025-11-15 06:31:11','2025-11-15 06:31:12',0),(20251114195137,'CreateAuditLogsTable','2025-11-14 23:57:09','2025-11-14 23:57:11',0),(20251114230642,'CreateSubscriptionHistoryTable','2025-11-15 03:09:26','2025-11-15 03:09:29',0),(20251115000545,'AddUserAuthAndPermissions','2025-11-15 04:13:35','2025-11-15 04:13:39',0),(20251115012954,'AddUserIdToSubscriptionHistory','2025-11-15 05:34:51','2025-11-15 05:34:53',0);
/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `phinxlog` with 6 row(s)
--

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rate_limits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `identifier_key` varchar(255) NOT NULL,
  `request_count` int(11) NOT NULL DEFAULT 1,
  `reset_at` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identifier_key` (`identifier_key`),
  KEY `idx_reset_at` (`reset_at`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de rate limits (fallback quando Redis não está disponível)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `rate_limits` VALUES (1,'ratelimit::tenant_1:60:2df18f4bb243db7805da72563bb2619b',3,1763160866,1763160806,1763160851),(2,'ratelimit::tenant_1:3600:2df18f4bb243db7805da72563bb2619b',17,1763164409,1763160809,1763168007),(3,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',2,1763160898,1763160838,1763160858),(4,'ratelimit::tenant_1:3600:3d2dd16387c5b2b6c15f00a314f302e2',23,1763164440,1763160840,1763168033),(5,'ratelimit::tenant_1:60:c1258a8afea49c93018a38c7a0a9a84e',1,1763160904,1763160844,1763160844),(6,'ratelimit::tenant_1:3600:c1258a8afea49c93018a38c7a0a9a84e',1,1763164447,1763160847,1763160847),(7,'ratelimit::tenant_1:60:2df18f4bb243db7805da72563bb2619b',9,1763161033,1763160973,1763161064),(8,'ratelimit::tenant_1:60:f97c50aaeba202cecaf34be506630f96',1,1763161046,1763160986,1763160986),(9,'ratelimit::tenant_1:3600:f97c50aaeba202cecaf34be506630f96',1,1763164589,1763160989,1763160989),(10,'ratelimit::tenant_1:60:96bba6b119a3add94b7b48de76c31a4e',3,1763161111,1763161051,1763161134),(11,'ratelimit::tenant_1:3600:96bba6b119a3add94b7b48de76c31a4e',3,1763164654,1763161054,1763161137),(12,'ratelimit::tenant_1:60:e6eb4274bcab75a413be314fa04bcdb5',1,1763162174,1763162114,1763162114),(13,'ratelimit::tenant_1:3600:e6eb4274bcab75a413be314fa04bcdb5',11,1763165716,1763162116,1763168046),(14,'ratelimit::tenant_1:60:9079b885b4dd601b72589bef1a860532',3,1763162254,1763162194,1763162231),(15,'ratelimit::tenant_1:3600:9079b885b4dd601b72589bef1a860532',3,1763165796,1763162196,1763162233),(16,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',4,1763166008,1763165948,1763166030),(17,'ratelimit::ip_::1:3600:37fad38087330284f77583a6f2b913fc',25,1763169551,1763165951,1763171895),(18,'ratelimit::tenant_1:60:6e5e928d8fb06e2df412898dafa8076a',2,1763166015,1763165955,1763166024),(19,'ratelimit::tenant_1:3600:6e5e928d8fb06e2df412898dafa8076a',3,1763169557,1763165957,1763166138),(20,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',4,1763166029,1763165969,1763166050),(21,'ratelimit::tenant_1:60:f1cb602c35e73dbea2eea68297357ca5',2,1763166035,1763165975,1763166043),(22,'ratelimit::tenant_1:3600:f1cb602c35e73dbea2eea68297357ca5',3,1763169577,1763165977,1763166158),(23,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',2,1763166190,1763166130,1763166143),(24,'ratelimit::tenant_1:60:6e5e928d8fb06e2df412898dafa8076a',1,1763166196,1763166136,1763166136),(25,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',2,1763166209,1763166149,1763166163),(26,'ratelimit::tenant_1:60:f1cb602c35e73dbea2eea68297357ca5',1,1763166216,1763166156,1763166156),(27,'ratelimit::tenant_1:60:e6eb4274bcab75a413be314fa04bcdb5',5,1763167828,1763167768,1763167881),(28,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',7,1763167834,1763167774,1763167868),(29,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',3,1763167849,1763167789,1763167849),(30,'ratelimit::tenant_1:60:2df18f4bb243db7805da72563bb2619b',3,1763167869,1763167809,1763167874),(31,'ratelimit::tenant_1:60:53ecd1111f850a5b8ba0b72b47cb1709',1,1763167947,1763167887,1763167887),(32,'ratelimit::tenant_1:3600:53ecd1111f850a5b8ba0b72b47cb1709',2,1763171489,1763167889,1763168052),(33,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',6,1763167954,1763167894,1763167998),(34,'ratelimit::tenant_1:60:245cfa272641e7fd7acafc6d9477fc5d',1,1763167960,1763167900,1763167900),(35,'ratelimit::tenant_1:3600:245cfa272641e7fd7acafc6d9477fc5d',2,1763171502,1763167902,1763168065),(36,'ratelimit::tenant_1:60:e6eb4274bcab75a413be314fa04bcdb5',5,1763167992,1763167932,1763168044),(37,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',3,1763168013,1763167953,1763168012),(38,'ratelimit::tenant_1:60:2df18f4bb243db7805da72563bb2619b',3,1763168032,1763167972,1763168037),(39,'ratelimit::tenant_1:60:3d2dd16387c5b2b6c15f00a314f302e2',3,1763168085,1763168025,1763168057),(40,'ratelimit::tenant_1:3600:2df18f4bb243db7805da72563bb2619b',1,1763171640,1763168040,1763168040),(41,'ratelimit::tenant_1:60:53ecd1111f850a5b8ba0b72b47cb1709',1,1763168110,1763168050,1763168050),(42,'ratelimit::tenant_1:3600:3d2dd16387c5b2b6c15f00a314f302e2',1,1763171659,1763168059,1763168059),(43,'ratelimit::tenant_1:60:245cfa272641e7fd7acafc6d9477fc5d',1,1763168123,1763168063,1763168063),(44,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',3,1763168774,1763168714,1763168773),(45,'ratelimit::tenant_1:60:6d0ee73650759187be1579bbd255b5f9',5,1763168781,1763168721,1763168786),(46,'ratelimit::tenant_1:3600:6d0ee73650759187be1579bbd255b5f9',10,1763172323,1763168723,1763169048),(47,'ratelimit::tenant_1:60:0021b7bd0c19b1e95e23e1b19624dec9',3,1763168794,1763168734,1763168753),(48,'ratelimit::tenant_1:3600:0021b7bd0c19b1e95e23e1b19624dec9',3,1763172336,1763168736,1763168756),(49,'ratelimit::tenant_1:60:4c83ef71f1482b144b9cc966b9a076d1',1,1763168807,1763168747,1763168747),(50,'ratelimit::tenant_1:3600:4c83ef71f1482b144b9cc966b9a076d1',1,1763172349,1763168749,1763168749),(51,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',3,1763169032,1763168972,1763169032),(52,'ratelimit::tenant_1:60:6d0ee73650759187be1579bbd255b5f9',5,1763169039,1763168979,1763169046),(53,'ratelimit::tenant_1:60:c588bcf44b2583e0dfb2d9e3ad2ab9bc',3,1763169052,1763168992,1763169012),(54,'ratelimit::tenant_1:3600:c588bcf44b2583e0dfb2d9e3ad2ab9bc',3,1763172595,1763168995,1763169015),(55,'ratelimit::tenant_1:60:3fc7a8a6fa4f5bfaceacbef68ef5e149',1,1763169066,1763169006,1763169006),(56,'ratelimit::tenant_1:3600:3fc7a8a6fa4f5bfaceacbef68ef5e149',1,1763172608,1763169008,1763169008),(57,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',3,1763169651,1763169591,1763169650),(58,'ratelimit::tenant_1:60:30983146e0c0f29208638c3e295d5e4b',4,1763169657,1763169597,1763169663),(59,'ratelimit::tenant_1:3600:30983146e0c0f29208638c3e295d5e4b',4,1763173199,1763169599,1763169665),(60,'ratelimit::tenant_1:60:88ab6a3e6f6e3d6cd0fb013a4c02bd26',5,1763169664,1763169604,1763169669),(61,'ratelimit::tenant_1:3600:88ab6a3e6f6e3d6cd0fb013a4c02bd26',5,1763173206,1763169606,1763169672),(62,'ratelimit::tenant_1:60:68201ed99f3f0b26dac53a58c461848b',1,1763169683,1763169623,1763169623),(63,'ratelimit::tenant_1:3600:68201ed99f3f0b26dac53a58c461848b',1,1763173225,1763169625,1763169625),(64,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',1,1763171175,1763171115,1763171115),(65,'ratelimit::tenant_1:60:9079b885b4dd601b72589bef1a860532',6,1763171182,1763171122,1763171161),(66,'ratelimit::tenant_1:3600:9079b885b4dd601b72589bef1a860532',12,1763174724,1763171124,1763171318),(67,'ratelimit::tenant_1:60:2a17b9cb88d308f67493d838e302b70c',1,1763171207,1763171147,1763171147),(68,'ratelimit::tenant_1:3600:2a17b9cb88d308f67493d838e302b70c',2,1763174750,1763171150,1763171305),(69,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',1,1763171329,1763171269,1763171269),(70,'ratelimit::tenant_1:60:9079b885b4dd601b72589bef1a860532',6,1763171336,1763171276,1763171316),(71,'ratelimit::tenant_1:60:2a17b9cb88d308f67493d838e302b70c',1,1763171362,1763171302,1763171302),(72,'ratelimit::ip_::1:60:37fad38087330284f77583a6f2b913fc',2,1763171916,1763171856,1763171893),(73,'ratelimit::tenant_1:60:0173882242e4ed9c7a352e118d39724a',5,1763171923,1763171863,1763171900),(74,'ratelimit::tenant_1:3600:0173882242e4ed9c7a352e118d39724a',5,1763175465,1763171865,1763171902);
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `rate_limits` with 74 row(s)
--

--
-- Table structure for table `stripe_events`
--

DROP TABLE IF EXISTS `stripe_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` varchar(255) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `processed` tinyint(1) DEFAULT 0,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_event_id` (`event_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_processed` (`processed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de eventos Stripe (idempotência de webhooks)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_events`
--

LOCK TABLES `stripe_events` WRITE;
/*!40000 ALTER TABLE `stripe_events` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `stripe_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `stripe_events` with 0 row(s)
--

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `customer_id` int(11) unsigned NOT NULL,
  `stripe_subscription_id` varchar(255) NOT NULL,
  `stripe_customer_id` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `plan_id` varchar(255) DEFAULT NULL,
  `plan_name` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `currency` varchar(3) DEFAULT 'usd',
  `current_period_start` datetime DEFAULT NULL,
  `current_period_end` datetime DEFAULT NULL,
  `cancel_at_period_end` tinyint(1) DEFAULT 0,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_stripe_subscription` (`stripe_subscription_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_subscriptions_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscriptions_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de assinaturas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `subscriptions` VALUES (1,1,1,'sub_test_1763162189','cus_TQMcRQySh3zPfX','active','price_test','Plano Teste',99.99,'BRL','2025-11-15 00:16:29','2025-12-15 00:16:29',0,'{\"test\":true}','2025-11-14 23:16:29','2025-11-14 23:16:29');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `subscriptions` with 1 row(s)
--

--
-- Table structure for table `subscription_history`
--

DROP TABLE IF EXISTS `subscription_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) unsigned NOT NULL COMMENT 'ID da assinatura (FK para subscriptions)',
  `tenant_id` int(11) unsigned NOT NULL COMMENT 'ID do tenant (para filtros rápidos)',
  `change_type` varchar(50) NOT NULL COMMENT 'Tipo de mudança: created, updated, canceled, reactivated, plan_changed, status_changed',
  `changed_by` varchar(50) DEFAULT NULL COMMENT 'Origem da mudança: api, webhook, admin',
  `user_id` int(11) unsigned DEFAULT NULL COMMENT 'ID do usuário que fez a mudança (quando via API com autenticação de usuário)',
  `old_status` varchar(50) DEFAULT NULL COMMENT 'Status anterior da assinatura',
  `new_status` varchar(50) DEFAULT NULL COMMENT 'Status novo da assinatura',
  `old_plan_id` varchar(255) DEFAULT NULL COMMENT 'ID do plano anterior (price_id)',
  `new_plan_id` varchar(255) DEFAULT NULL COMMENT 'ID do plano novo (price_id)',
  `old_amount` decimal(10,2) DEFAULT NULL COMMENT 'Valor anterior (em formato monetário)',
  `new_amount` decimal(10,2) DEFAULT NULL COMMENT 'Valor novo (em formato monetário)',
  `old_currency` varchar(3) DEFAULT NULL COMMENT 'Moeda anterior',
  `new_currency` varchar(3) DEFAULT NULL COMMENT 'Moeda nova',
  `old_current_period_end` datetime DEFAULT NULL COMMENT 'Fim do período anterior',
  `new_current_period_end` datetime DEFAULT NULL COMMENT 'Fim do período novo',
  `old_cancel_at_period_end` tinyint(1) DEFAULT 0 COMMENT 'Cancelar ao fim do período anterior',
  `new_cancel_at_period_end` tinyint(1) DEFAULT 0 COMMENT 'Cancelar ao fim do período novo',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Metadados adicionais da mudança (JSON)' CHECK (json_valid(`metadata`)),
  `description` text DEFAULT NULL COMMENT 'Descrição da mudança (opcional)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Data e hora da mudança',
  PRIMARY KEY (`id`),
  KEY `idx_subscription_id` (`subscription_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_change_type` (`change_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_subscription_created` (`subscription_id`,`created_at`),
  KEY `idx_tenant_created` (`tenant_id`,`created_at`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_subscription_history_subscription_id` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscription_history_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscription_history_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Histórico de mudanças de assinaturas - auditoria de alterações';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_history`
--

LOCK TABLES `subscription_history` WRITE;
/*!40000 ALTER TABLE `subscription_history` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `subscription_history` VALUES (1,1,1,'created','api',NULL,NULL,'active',NULL,'price_1',NULL,99.99,NULL,'BRL',NULL,NULL,NULL,NULL,NULL,'Assinatura criada','2025-11-14 23:16:29'),(2,1,1,'plan_changed','api',NULL,NULL,NULL,'price_1','price_2',99.99,149.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Plano alterado de price_1 para price_2','2025-11-14 23:16:29'),(3,1,1,'status_changed','api',NULL,'active','past_due',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Status alterado de active para past_due','2025-11-14 23:16:29'),(4,1,1,'canceled','api',NULL,'active','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,'Assinatura marcada para cancelar no final do período','2025-11-14 23:16:30'),(5,1,1,'reactivated','api',NULL,'active','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,'Assinatura reativada','2025-11-14 23:16:30');
/*!40000 ALTER TABLE `subscription_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `subscription_history` with 5 row(s)
--

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenants` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `api_key` varchar(64) NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_api_key` (`api_key`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de tenants (clientes SaaS)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `tenants` VALUES (1,'Tenant de Teste','f4251d66540dd06fb6ce119c5ce2bc7ece397d9a4862ec7cb95501a854e1f317','active','2025-11-14 23:59:31','2025-11-14 23:59:31'),(2,'SaaS de Exemplo','cd289b96ab16dc58e2ebdcbca83a568716236708fc26392f9fc22accd502095e','active','2025-11-14 23:22:33','2025-11-14 23:22:33');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `tenants` with 2 row(s)
--

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `role` enum('admin','viewer','editor') NOT NULL DEFAULT 'viewer' COMMENT 'Role do usuário: admin (todas permissões), editor (editar), viewer (apenas visualizar)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tenant_email` (`tenant_id`,`email`),
  KEY `idx_email` (`email`),
  KEY `idx_tenant_id` (`tenant_id`),
  CONSTRAINT `fk_users_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de usuários';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `users` VALUES (2,1,'admin@example.com','$2y$10$2cGT6i1T0pTJbGZAShQTIOZz2.HTzW0YJnBQANEODWNy3NcN3Fpmi','Administrador','active','admin','2025-11-15 04:14:50','2025-11-15 04:14:50'),(3,1,'editor@example.com','$2y$10$GAvyJhvCXTpuu0osNVapq.j/SjcgcQdXGPu8ERJalA1o4pXCZi9Pe','Editor','active','editor','2025-11-15 04:14:50','2025-11-15 04:14:50'),(4,1,'viewer@example.com','$2y$10$QU2yLUv4HLl/3Y8/4sT1FeWc95OZNjic0VhsfZL6c2l761T8U/2qm','Visualizador','active','viewer','2025-11-15 04:14:50','2025-11-15 04:14:50'),(5,1,'test_user_1763168723@example.com','$2y$10$OXfCuFhyrN06GT5LskJdAeteSQV23Qg2fLf75zQkBDaHaQJyQIt2u','Updated Test User','inactive','editor','2025-11-15 01:05:30','2025-11-15 01:05:56'),(6,1,'test_user_1763168981@example.com','$2y$10$hTnF3rwjdz99DNm8dRK14ObjvyEo7Qk5EVaH/upndSyAry2egxRHy','Updated Test User','inactive','editor','2025-11-15 01:09:48','2025-11-15 01:10:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `users` with 5 row(s)
--

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT 'ID do usuário',
  `permission` varchar(100) NOT NULL COMMENT 'Nome da permissão (ex: view_subscriptions, create_subscriptions)',
  `granted` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Se a permissão está concedida (true) ou negada (false)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Data de criação',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`,`permission`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_user_permissions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Permissões específicas de usuários - controle granular além das roles';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user_permissions` VALUES (1,4,'view_audit_logs',0,'2025-11-15 01:20:13');
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user_permissions` with 1 row(s)
--

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_sessions` (
  `id` varchar(64) NOT NULL COMMENT 'Token de sessão (hash)',
  `user_id` int(11) unsigned NOT NULL COMMENT 'ID do usuário',
  `tenant_id` int(11) unsigned NOT NULL COMMENT 'ID do tenant',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP do cliente',
  `user_agent` text DEFAULT NULL COMMENT 'User-Agent do cliente',
  `expires_at` datetime NOT NULL COMMENT 'Data de expiração da sessão',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Data de criação',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_session_id` (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `fk_user_sessions_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sessões de usuários autenticados - tokens de acesso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user_sessions` VALUES ('04f0fa561cff7ae01d279cbf4273ed5046caf513a1a23bb0f9852935bbcf2b3c',3,1,'::1',NULL,'2025-11-16 01:50:18','2025-11-15 00:50:18'),('0841755cba9ffa3f3d73eba2e3ef0bc3e187a741eabd6ed26177725362b0c46f',4,1,'::1',NULL,'2025-11-16 01:50:51','2025-11-15 00:50:51'),('10b7fa2e63afbea8f36635f3189dcdc2328128272ec524fe322a0e5dd629cebb',2,1,'::1',NULL,'2025-11-16 02:05:16','2025-11-15 01:05:16'),('126e8bb920311cda17ead08dc753c9458d40c302de9603d9240f40d710d3edb0',3,1,'::1',NULL,'2025-11-16 02:58:15','2025-11-15 01:58:15'),('3dea32fcf56d48c0dc73db543fb30e909bf80529bad5bcd25683b59dd0f7d462',4,1,'::1',NULL,'2025-11-16 01:53:34','2025-11-15 00:53:34'),('43a63f7a6ab5e91c1e17deb7f673e257b9ac80c8c7f6dc128add482589f392a1',3,1,'::1',NULL,'2025-11-16 02:10:21','2025-11-15 01:10:21'),('4426c8f2c3677981d279a34a2c293e57e230f266b39ad1222cccefce8cf041c8',2,1,'::1',NULL,'2025-11-16 02:45:17','2025-11-15 01:45:17'),('4a0eb8a7b45691f2171d23be546a6d6e1ac6f66a801a18d8b7a581e1dd8a04d7',2,1,'::1',NULL,'2025-11-16 01:49:52','2025-11-15 00:49:52'),('4abe737fa27143f3b1cc056505a2f733f443e2ede160f98d148ebbfe14efb0f4',4,1,'::1',NULL,'2025-11-16 02:10:35','2025-11-15 01:10:35'),('68926163d0ef6a2fe71d0f6ae240151b6f3038e16ad348cebe8e397a124fdb69',4,1,'::1',NULL,'2025-11-16 02:06:15','2025-11-15 01:06:15'),('7c1f897d6eda6c8d9f6f441ee2a704b8cf77a24ebfe15847006f4094a58d1551',3,1,'::1',NULL,'2025-11-16 01:53:01','2025-11-15 00:53:01'),('7deef27c48b16d5a0d4890ad55495f8fc1ab60238f9bec88f78f479cb8b1f034',2,1,'::1',NULL,'2025-11-16 02:19:53','2025-11-15 01:19:53'),('8ec39603a116b90da16970200ef2e24a7dd4a705c5cd5a5423179f78c12e3612',2,1,'::1',NULL,'2025-11-16 02:57:38','2025-11-15 01:57:38'),('96eccc08c4f82164cc5918b3a5144eb356d382de486eb45d2973540d79723049',3,1,'::1',NULL,'2025-11-16 02:20:39','2025-11-15 01:20:39'),('a9bda8f44b4ea1eeca34e748829f21f4aded5df97cf5dd405e8bb44a834b2dfb',4,1,'::1',NULL,'2025-11-16 02:20:52','2025-11-15 01:20:52'),('bcd6e28a5a38bf62d27e72e1100603514e4cb406259bd2a5da116fceec69fcb3',2,1,'::1',NULL,'2025-11-16 02:47:52','2025-11-15 01:47:52'),('c12ec2e08260719186660e4b73806f6c46ee4d46a27da4984c0f159f1643177e',2,1,'::1',NULL,'2025-11-16 01:52:35','2025-11-15 00:52:35'),('f4386a01b2e21295a16562439596f4e042177d1f6b7caa6ceba261ec5c316505',2,1,'::1',NULL,'2025-11-16 02:09:35','2025-11-15 01:09:35'),('f9404e6d6a7e4fb7fa15de0c4a70bf523a6763f5d74fde61ca7b378b8e02ee21',3,1,'::1',NULL,'2025-11-16 02:06:02','2025-11-15 01:06:02');
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user_sessions` with 19 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Sat, 15 Nov 2025 03:52:55 +0100
